import { getStore } from "https://esm.sh/@netlify/blobs@8.1.0";

const STORE_NAME = "ad_midia_hub_cloud_db";
const STATE_KEY = "global_app_state_v2_qr";

export default async (req, context) => {
  try {
    const store = getStore({ name: STORE_NAME, consistency: "strong" });

    if (req.method === "GET") {
      const saved = await store.get(STATE_KEY, { type: "json" });
      return Response.json(
        {
          ok: true,
          data: saved || null,
          serverTime: new Date().toISOString()
        },
        {
          headers: {
            "Cache-Control": "no-store, no-cache, must-revalidate"
          }
        }
      );
    }

    if (req.method === "POST") {
      const body = await req.json();
      if (!body || !Array.isArray(body.members) || !Array.isArray(body.schedules) || !Array.isArray(body.roles)) {
        return Response.json({ ok: false, error: "Formato de dados inválido." }, { status: 400 });
      }

      const payload = {
        roles: body.roles,
        members: body.members,
        schedules: body.schedules,
        updatedAt: new Date().toISOString(),
        updatedBy: body.updatedBy || "system"
      };

      await store.setJSON(STATE_KEY, payload);

      return Response.json(
        {
          ok: true,
          updatedAt: payload.updatedAt
        },
        {
          headers: {
            "Cache-Control": "no-store, no-cache, must-revalidate"
          }
        }
      );
    }

    return Response.json({ ok: false, error: "Method not allowed" }, { status: 405 });
  } catch (err) {
    console.error("Edge cloud sync error:", err);
    return Response.json(
      { ok: false, error: err?.message || "Erro interno no servidor de banco de dados." },
      { status: 500 }
    );
  }
};

export const config = {
  path: "/api/state"
};
